from flask import Blueprint, request, jsonify
from models import Comment, db
from utils.auth_middleware import token_required

comment_bp = Blueprint('comment_bp', __name__)

@comment_bp.route('/comments', methods=['POST'])
@token_required
def add_comment():
    data = request.json
    new_comment = Comment(content=data['content'], user_id=request.user_id, article_id=data['article_id'])
    db.session.add(new_comment)
    db.session.commit()
    return jsonify({'message': 'Comment added'}), 201

@comment_bp.route('/comments/<int:id>', methods=['DELETE'])
@token_required
def delete_comment(id):
    comment = Comment.query.get_or_404(id)
    if comment.user_id != request.user_id:
        return jsonify({'message': 'Unauthorized'}), 403
    db.session.delete(comment)
    db.session.commit()
    return jsonify({'message': 'Comment deleted'})