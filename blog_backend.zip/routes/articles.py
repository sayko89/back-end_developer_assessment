from flask import Blueprint, request, jsonify
from models import Article, Like, db
from utils.auth_middleware import token_required

article_bp = Blueprint('article_bp', __name__)

@article_bp.route('/articles', methods=['GET'])
def get_articles():
    articles = Article.query.all()
    result = []
    for a in articles:
        likes = Like.query.filter_by(article_id=a.id, is_like=True).count()
        dislikes = Like.query.filter_by(article_id=a.id, is_like=False).count()
        result.append({
            'id': a.id,
            'title': a.title,
            'content': a.content,
            'likes': likes,
            'dislikes': dislikes
        })
    return jsonify(result)

@article_bp.route('/articles/<int:id>', methods=['GET'])
def get_article(id):
    article = Article.query.get_or_404(id)
    likes = Like.query.filter_by(article_id=article.id, is_like=True).count()
    dislikes = Like.query.filter_by(article_id=article.id, is_like=False).count()
    return jsonify({
        'title': article.title,
        'content': article.content,
        'likes': likes,
        'dislikes': dislikes
    })

@article_bp.route('/articles', methods=['POST'])
@token_required
def create_article():
    data = request.json
    new_article = Article(title=data['title'], content=data['content'], user_id=request.user_id)
    db.session.add(new_article)
    db.session.commit()
    return jsonify({'message': 'Article created'}), 201

@article_bp.route('/articles/<int:id>', methods=['PUT'])
@token_required
def update_article(id):
    article = Article.query.get_or_404(id)
    if article.user_id != request.user_id:
        return jsonify({'message': 'Unauthorized'}), 403
    data = request.json
    article.title = data['title']
    article.content = data['content']
    db.session.commit()
    return jsonify({'message': 'Article updated'})

@article_bp.route('/articles/<int:id>', methods=['DELETE'])
@token_required
def delete_article(id):
    article = Article.query.get_or_404(id)
    if article.user_id != request.user_id:
        return jsonify({'message': 'Unauthorized'}), 403
    db.session.delete(article)
    db.session.commit()
    return jsonify({'message': 'Article deleted'})

@article_bp.route('/articles/<int:id>/like', methods=['POST'])
@token_required
def like_article(id):
    data = request.json
    is_like = data.get("is_like")  # True or False

    existing = Like.query.filter_by(user_id=request.user_id, article_id=id).first()
    if existing:
        existing.is_like = is_like
    else:
        new_like = Like(user_id=request.user_id, article_id=id, is_like=is_like)
        db.session.add(new_like)

    db.session.commit()
    return jsonify({'message': 'Your vote was recorded'}), 200